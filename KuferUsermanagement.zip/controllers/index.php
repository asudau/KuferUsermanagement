<?php
//require_once 'lib/classes/DBManager.class.php';


class IndexController extends StudipController {

    public function __construct($dispatcher)
    {
        parent::__construct($dispatcher);
        $this->plugin = $dispatcher->plugin;
        Navigation::activateItem('course/contact');
    }

    public function before_filter(&$action, &$args)
    {
        parent::before_filter($action, $args);

        
        PageLayout::setTitle($this->course->getFullname()." - " ._("Kufer Nutzerverwaltung"));
            
        $navcreate = new LinksWidget();
        $navcreate->setTitle('Navigation');
        $navcreate->addLink("�bersicht", PluginEngine::getLink($this->plugin, array(), 'index'));
        
        Sidebar::get()->addWidget($navcreate);
        
        if($perm->have_studip_perm('dozent', $this->course->id)){
            $actions = new ActionsWidget();
            $actions->setTitle(_('Aktionen'));

            $actions->addLink(
            'Einstellungen',
            $this->url_for('index/'), Icon::create('admin', 'clickable')); 

            Sidebar::get()->addWidget($actions);
        }
    }

    public function index_action()
    {
        
        
    }
   
    
    private function get_user_data($course_id, $status){
        $db = DBManager::get();
        $query = "SELECT u.username, u.user_id, u.Vorname, u.Nachname, uo.last_lifesign, COUNT(fe.topic_id) AS Forenbeitraege
			FROM seminar_user su 
                        LEFT JOIN auth_user_md5 u ON u.user_id = su.user_id
			LEFT JOIN user_online uo ON u.user_id = uo.user_id
                        LEFT JOIN forum_entries fe ON (u.user_id = fe.user_id AND fe.seminar_id = :sem_id)
                        WHERE su.Seminar_id = :sem_id
                        AND su.status = :status
			GROUP BY u.user_id";
                            
        $statement = $db->prepare($query);
        $statement->execute(array('sem_id' => $course_id, 'status' =>$status));
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }
    
    
    // customized #url_for for plugins
    public function url_for($to)
    {
        $args = func_get_args();

        # find params
        $params = array();
        if (is_array(end($args))) {
            $params = array_pop($args);
        }

        # urlencode all but the first argument
        $args = array_map('urlencode', $args);
        $args[0] = $to;

        return PluginEngine::getURL($this->dispatcher->plugin, $params, join('/', $args));
    }
}
