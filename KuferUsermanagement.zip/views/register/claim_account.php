


<div class="button-group">
    <?= Studip\LinkButton::create(_("Hier geht's zum Login"), URLHelper::getLink('index.php') . '?again=yes') ?>
</div>
